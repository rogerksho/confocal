import time
import serial
from funcs import *
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal
import csv

#filename = "scans/1722716630.csv"
filename = "scans/0x_0y.csv"
filename2 = "scans/04x_0y.csv"
#filename = "scans/1722807888.csv"

reverse_t = True
med_filt_active = 0
plot_3d = 0

XY_step_size = 0.003175 # mm/step

z_map = list()

row_size = 1

with open(filename, newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    if reverse_t:
        ticker = True
        for row in spamreader:
            if ticker:
                z_map.append(row)
            else:
                z_map.append(list(reversed(row)))
            ticker = not ticker
    else:
        for row in spamreader:
            z_map.append(row)
            
z_map2 = list()
with open(filename2, newline='') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    if False:
        ticker = True
        for row in spamreader:
            if ticker:
                z_map2.append(row)
            else:
                z_map2.append(list(reversed(row)))
            ticker = not ticker
    else:
        for row in spamreader:
            z_map.append(list(reversed(row)))
            
row_size = len(z_map)
column_size = len(z_map[0])

z_map_int = [[int(numeric_string) for numeric_string in row] for row in z_map]
#z_map_int2 = [[int(numeric_string) for numeric_string in row] for row in z_map2]

#z_map_int = z_map_int.extend(z_map_int2)

if med_filt_active:
    z_map_int = signal.medfilt2d(z_map_int, kernel_size=11)

if plot_3d:
    hf = plt.figure()
    ha = hf.add_subplot(111, projection='3d')
    
    x = np.arange(0, row_size*XY_step_size, XY_step_size)
    y = np.arange(0, column_size*XY_step_size, XY_step_size)
    
    print(len(x))
    print(len(z_map[0]))

    X, Y = np.meshgrid(x, y)  # `plot_surface` expects `x` and `y` data to be 2D
    ha.plot_surface(X, Y, z_map_int)

    plt.show()
else:
    plt.imshow(z_map_int, interpolation="sinc")
    plt.show()